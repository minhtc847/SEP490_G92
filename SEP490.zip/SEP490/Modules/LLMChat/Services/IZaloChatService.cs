﻿namespace SEP490.Modules.LLMChat.Services
{
    public interface IZaloChatService
    {
    }
}
