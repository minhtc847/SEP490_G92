﻿namespace SEP490.Modules.Production_plans.DTO
{
    public class UpdateProductionPlanStatusDTO
    {
        public string Status { get; set; } = string.Empty;
    }
}
