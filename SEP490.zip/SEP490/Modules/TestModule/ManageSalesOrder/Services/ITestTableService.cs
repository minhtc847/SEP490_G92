﻿namespace SEP490.Modules.SalesOrder.ManageSalesOrder.Services
{
    public interface ITestTableService
    {
        public List<DB.Models.TestTable> GetAll();
    }
}
