﻿namespace SEP490.Modules.OrderModule.ManageOrder.DTO
{
    public class GlassStructureDto
    {
        public int Id { get; set; }
        public string? ProductCode { get; set; }
        public string? ProductName { get; set; }
        public int? UnitPrice { get; set; }
    }

}
