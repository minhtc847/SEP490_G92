﻿namespace SEP490.Selenium.SaleOrder.DTO
{
    public class SaleOrderProductsInput
    {
        public string ProductCode { get; set; }
        public string ProductQuantity { get; set; }
    }
}
