﻿namespace SEP490.Selenium.ProductionOrder.DTO
{
    public class InputProduct
    {
        public string InputProductCode { get; set; }
        public int InputProductQuantity { get; set; }

    }
}
