﻿namespace SEP490.Common.Services
{
    public class BaseService
    {
    }
}
