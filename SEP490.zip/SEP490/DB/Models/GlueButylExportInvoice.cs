﻿namespace SEP490.DB.Models
{
    public class GlueButylExportInvoice
    {
        public int Id { get; set; }
    }
}
