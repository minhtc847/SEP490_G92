﻿namespace SEP490.DB.Models
{
    public class TestTable
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime CreateAt { get; set; }
    }
}
